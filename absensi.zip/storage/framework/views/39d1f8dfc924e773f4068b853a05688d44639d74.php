<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->cekin == ''): ?>
                    <div class="card-header"><?php echo e(__('CHECKIN')); ?></div>
                <?php endif; ?>
                <?php if($item->cekin !== '' && $item->cekout == '00:00:00'): ?>
                    <div class="card-header"><?php echo e(__('CHECKOUT')); ?></div>
                <?php endif; ?>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <?php if($item->cekin == ''): ?>
                        <form id="location-form" action="<?php echo e(route('checkin')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <label for="nama">Nama:</label>
                            <input type="hidden" class="form-control" name="nama" id="nama" value="<?php echo e(Auth::user()->id); ?>" required><br>
                            <input type="text" class="form-control" name="namax" id="namax" value="<?php echo e(Auth::user()->name); ?>" required><br>
                            <label for="nama">Latitude</label>
                            <input type="text" class="form-control" name="lat" id="lat" ><br>
                            <label for="nama">longtitude</label>
                            <input type="text" class="form-control" name="long" id="long" ><br>
                            <button class="btn btn-primary btn-lg" id="checkin" type="submit">CHECK IN</button>
                        </form>    
                    

                    <?php elseif($item->cekin !== '' && $item->cekout == '00:00:00'): ?>
                    <p style="color: red">Anda Sudah Checkin silakan untuk melakukan Checkout</p>
                    <form id="location-form" action="<?php echo e(route('checkout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <label for="nama">Nama:</label>
                        <input type="hidden" class="form-control" name="id" id="id" value="<?php echo e($item->id); ?>" required><br>
                        <input type="hidden" class="form-control" name="nama" id="nama" value="<?php echo e(Auth::user()->id); ?>" required><br>
                        <input type="text" class="form-control" name="namax" id="namax" value="<?php echo e(Auth::user()->name); ?>" required><br>
                        <label for="nama">Latitude</label>
                        <input type="text" class="form-control" name="lat" id="lat" ><br>
                        <label for="nama">longtitude</label>
                        <input type="text" class="form-control" name="long" id="long" ><br>
                        <button class="btn btn-primary btn-lg" id="checkout" type="submit">CHECK OUT</button>
                    </form>

                    <?php else: ?>
                    <form id="location-form" action="<?php echo e(route('checkin')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <label for="nama">Nama:</label>
                        <input type="hidden" class="form-control" name="nama" id="nama" value="<?php echo e(Auth::user()->id); ?>" required><br>
                        <input type="text" class="form-control" name="namax" id="namax" value="<?php echo e(Auth::user()->name); ?>" required><br>
                        <label for="nama">Latitude</label>
                        <input type="text" class="form-control" name="lat" id="lat" ><br>
                        <label for="nama">longtitude</label>
                        <input type="text" class="form-control" name="long" id="long" ><br>
                        <button class="btn btn-primary btn-lg" id="checkin" type="submit">CHECK IN</button>
                    </form>    
                <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<script src=" https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js "></script>
<script>
    // const locationForm = document.getElementById('location-form');
    
    // locationForm.addEventListener('submit', function(e) {
    //     e.preventDefault();

        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(function(position) {
                const lat = position.coords.latitude;
                const long = position.coords.longitude;

                // Isi nilai input tersembunyi dengan Lat dan Long
                const latInput = document.createElement('input');
                latInput.type = 'hidden';
                latInput.name = 'lat';
                latInput.value = lat;
                // locationForm.appendChild(latInput);

                const longInput = document.createElement('input');
                longInput.type = 'hidden';
                longInput.name = 'long';
                longInput.value = long;
                // locationForm.appendChild(longInput);

                $("#lat").val(lat)
                $("#long").val(long)



                // Lanjutkan dengan mengirim formulir
                // locationForm.submit();
            });
        } else {
            alert('Geolocation tidak didukung oleh browser Anda.');
        }
    // });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\absensi\resources\views/kehadiran.blade.php ENDPATH**/ ?>