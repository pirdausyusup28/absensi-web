<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Kehadiran')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('home')); ?>" method="GET">
                        <?php echo csrf_field(); ?>
                        <label for="nama">Tanggal Awal</label>
                        <input type="date" class="form-control" name="tgl_awal" id="tgl_awal" ><br>
                        <label for="nama">Tanggal Akhir</label>
                        <input type="date" class="form-control" name="tgl_akhir" id="tgl_akhir" ><br>
                        <button class="btn btn-primary btn-sm" id="checkout" type="submit">Filter data</button>
                    </form>
<br>

                    <table class="table table-striped" id="tabel">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>ID USER</th>
                                <th>Tanggal</th>
                                <th>Jam Cekin</th>
                                <th>Jam Cekout</th>
                                <th>Lat</th>
                                <th>Long</th>
                                <th>Lat Cekout</th>
                                <th>Long Cekout</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $nomor = 1; // Inisialisasi nomor urut
                            ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <tr>
                                    <td><?php echo e($nomor++); ?></td>
                                    <td><?php echo e($item->id_karyawan); ?></td>
                                    <td><?php echo e($item->tanggal); ?></td>
                                    <td><?php echo e($item->cekin); ?></td>
                                    <td><?php echo e($item->cekout); ?></td>
                                    <td><?php echo e($item->latitude); ?></td>
                                    <td><?php echo e($item->longitude); ?></td>
                                    <td><?php echo e($item->latitude_out); ?></td>
                                    <td><?php echo e($item->longitude_out); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                    <?php if(count($data) > 0): ?>
                    
                        
                        
                        <button class="btn btn-success btn-sm" id="exportButton" type="submit">Download Excel</button>
                    
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.8/xlsx.full.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/1.3.8/FileSaver.min.js"></script>

<script>
    document.getElementById('exportButton').addEventListener('click', function() {
      var table = document.getElementById('tabel');
      var tableHTML = table.outerHTML;
  
      var blob = new Blob([tableHTML], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  
      var blobUrl = URL.createObjectURL(blob);
  
      var link = document.createElement("a");
      link.href = blobUrl;
      link.download = "rekap_kehadiran.xls";
      link.style.display = "none";
  
      document.body.appendChild(link);
      link.click();
  
      document.body.removeChild(link);
    });
  </script>
  
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\absensi\resources\views/home.blade.php ENDPATH**/ ?>